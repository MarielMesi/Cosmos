Moralis.initialize("moOtqrP0nrrOsorAeR4pqYSmf2D5So5v45JoRedf"); // Application id from moralis.io
Moralis.serverURL = "https://jgdh801fiqzc.usemoralis.com:2053/server"; //Server url from moralis.io
Moralis.start({ serverUrl, appId});


function fetchNFTMetadata(NFTs){
    for (let i = 0; i < NFTs.length; i++) {
        let nft = NFTs[i];
        let id  = nft.token_id;
        //Call Moralis Cloud function -> Static Json file 
        fetch("")
    }

}






async function initializeApp() {
    let currentUser = Moralis.User.current();
        if(!currentUser){
            currentUser = await Moralis.Web3.authenticate();
        }
        alert("Signed in succesfully.")
        
        const options = { address: "0xbe62937c7aea794d9e7800155c210fd1eeab684d", chain: "rinkeby" };
        let NFTs = await Moralis.Web3API.token.getAllTokenIds(options);
        console.log(NFTs);
    }


    initializeApp();